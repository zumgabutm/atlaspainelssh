#!/bin/sh
curl —silent https://seudominio/onlines.php >/dev/null 2>&1 && curl —silent https://seudominio/checkpag.php >/dev/null 2>&1