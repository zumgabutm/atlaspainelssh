// Menu Icon Color Config
var menuIconColorsObj = {
  iconStrokeColor    : "#8494A7",
  iconSolidColor     : "#8494A7",
  iconFillColor      : "#d4ebf9",
  iconStrokeColorAlt : "#E67E22"
};


// Active Menu Icon Color Config
var menuActiveIconColorsObj = {
  iconStrokeColor    : "#5A8DEE",
  iconSolidColor     : "#5A8DEE",
  iconFillColor      : "#d4ebf9",
  iconStrokeColorAlt : "#E67E22"
};
