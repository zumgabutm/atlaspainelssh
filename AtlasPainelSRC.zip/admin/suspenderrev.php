<?php
error_reporting(0);
session_start();

function security(){
    date_default_timezone_set('America/Sao_Paulo');
        $_SESSION['sgdfsr43erfggfd4rgs3rsdfsdfsadfe'] = true;
        $_SESSION['token_invalido_'] = false;
}


?>